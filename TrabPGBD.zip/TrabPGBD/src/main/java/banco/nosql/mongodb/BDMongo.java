/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package banco.nosql.mongodb;

class BDMongo {
   
    public static final String URL_CONEXAO = "mongodb://localhost:27017";
    public static final String DATABASE = "registros";
    public static final String COLLECTION = "eventos";

}
