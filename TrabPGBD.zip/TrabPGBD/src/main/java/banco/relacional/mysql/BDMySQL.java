/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package banco.relacional.mysql;

public class BDMySQL {
    
    public static final String JDBC_DRIVER = "com.mysql.cj.jdbc.Driver";
    static final String USUARIO = "root";
    static final String SENHA = "";
    static final String URL_CONEXAO = "jdbc:mysql://localhost/pgbd?useSSL=false";
   
}
