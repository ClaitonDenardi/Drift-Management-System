package banco;

public class Registro {
    
}
